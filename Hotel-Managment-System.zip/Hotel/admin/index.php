<?php  
 session_start();  
 if(isset($_SESSION["admin"])){  
    header("location:home.php");  
 }  
 ?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>ADMIN</title>
      <link rel="stylesheet" href="css/style.css">
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <style>
         input{
            margin-bottom:10px;
        }
    		nav{
         border-radius:0px !important;
			overflow:hidden;
			width:100vw;
			background: #333;
			position: sticky;
			top: 0px;
		}
		ul{
			list-style: none;
			float:right;
			margin-right: 20px;			
		}
		li{
			float:left;
			margin: 10px;
			letter-spacing:1px;
		}
		a{
			color: #f5f5f5;	
			outline:none;
			text-decoration:none;
		}
		a:hover{
			color: #f5f5f5;	
			border-bottom:2px solid #ff0;
		}
    </style>
</head>  
<body>

<!-- <div class="bottom">  <h3><a href="../index.php">HOMEPAGE</a></h3></div> -->
<nav class="navbar">
   <ul>
      <li>
         <a  href="../index.php" class="nav-link">Homepage</a>
      </li>
   </ul>
</nav>
    <div class="login-page bk-img">
		<div class="form-content">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<h1 class="text-center text-bold text-light mt-4x">Hotel Management System login</h1>
						<div class="well row bk-light">
							<div class="col-md-8 col-md-offset-2">
								<form method="post">
									<label for="" class="text-uppercase text-sm">Your Username </label>
									<input type="text" placeholder="Username" name="user" class="form-control mb">
									<label for="" class="text-uppercase text-sm">Password</label>
									<input type="password" placeholder="Password" name="pass" class="form-control mb">
									<button class="btn btn-primary btn-block" name="login" type="submit">LOGIN</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
<?php
   include('db.php');
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($con,$_POST['user']);
      $mypassword = mysqli_real_escape_string($con,$_POST['pass']); 
      
      $sql = "SELECT id FROM login WHERE usname = '$myusername' and pass = '$mypassword'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      if($count == 1) {
         
         $_SESSION['admin'] = $myusername;
         
         header("location: home.php");
      }else {
         echo '<script>alert("Your Login Name or Password is invalid") </script>' ;
      }
   }
?>

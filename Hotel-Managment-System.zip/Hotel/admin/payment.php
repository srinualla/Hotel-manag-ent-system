<?php  
session_start();  
if(!isset($_SESSION["admin"]))
{
 header("location:index.php");
}
?> 
<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>HOTEL</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        
    <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                </button>
                <a class="navbar-brand" href="home.php"> <?php echo $_SESSION["admin"]; ?> </a>
            </div>
        </nav>
        <div class="sidebar-collapse">
            <nav class="navbar-default navbar-side" role="navigation">
                <ul class="nav" id="main-menu">
                    <li>
                        <a  href="home.php"><i class="fa fa-dashboard"></i> Status</a>
                    </li>
                    <li>
                        <a href="roombook.php"><i class="fa fa-bar-chart-o"></i> Room Booking</a>
                    </li>
                    <li>
                        <a  class="active-menu" href="payment.php"><i class="fa fa-qrcode"></i> Payment</a>
                    </li>
                    <li>
                        <a  href="room.php"><i class="fa fa-qrcode"></i> Room</a>
                    </li>
                    <li>
                        <a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </nav>
            <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Payment Details<small> </small>
                    </h1>
            </div>
        </div> 
                 <!-- /. ROW  -->
				 
				 
    <div class="row">
        <div class="col-md-12">
            <!-- Advanced Tables -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Room type</th>
                                    <th>Bed Type</th>
                                    <th>Check in</th>
                                    <th>Check out</th>
                                    <th>No of Room</th>
                                    <th>Meal Type</th>
                                    
                                    <th>Room Rent</th>
                                    <th>Bed Rent</th>
                                    <th>Meals </th>
                                    <th>Gr.Total</th>
                                    <th>Print</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                
                            <?php
                                include ('db.php');
                                $sql="select * from payment";
                                $re = mysqli_query($con,$sql);
                                while($row = mysqli_fetch_array($re))
                                {
                                
                                    $id = $row['id'];
                                    
                                    if($id % 2 ==1 )
                                    {
                                        echo"<tr class='gradeC'>
                                            <td>".$row['title']." ".$row['name']."</td>
                                            <td>".$row['troom']."</td>
                                            <td>".$row['tbed']."</td>
                                            <td>".$row['cin']."</td>
                                            <td>".$row['cout']."</td>
                                            <td>".$row['nroom']."</td>
                                            <td>".$row['meal']."</td>
                                            
                                            <td>".$row['ttot']."</td>
                                            <td>".$row['mepr']."</td>
                                            <td>".$row['btot']."</td>
                                            <td>".$row['fintot']."</td>
                                            <td><a href=print.php?pid=".$id ." <button class='btn btn-primary'> <i class='fa fa-print' ></i> Print</button></td>
                                            </tr>";
                                    }
                                    else
                                    {
                                        echo"<tr class='gradeU'>
                                            <td>".$row['title']." ".$row['name']."</td>
                                            <td>".$row['troom']."</td>
                                            <td>".$row['tbed']."</td>
                                            <td>".$row['cin']."</td>
                                            <td>".$row['cout']."</td>
                                            <td>".$row['nroom']."</td>
                                            <td>".$row['meal']."</td>
                                            
                                            <td>".$row['ttot']."</td>
                                            <td>".$row['mepr']."</td>
                                            <td>".$row['btot']."</td>
                                            <td>".$row['fintot']."</td>
                                            <td><a href=print.php?pid=".$id ." <button class='btn btn-primary'> <i class='fa fa-print' ></i> Print</button></td>
                                            </tr>";
                                    
                                    }
                                
                                }
                                
                            ?>
                                
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
            <!--End Advanced Tables -->
        </div>
    </div>
        <!-- /. ROW  -->
    
        </div>
        
    </div>
        
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/custom-scripts.js"></script>
</body>
</html>

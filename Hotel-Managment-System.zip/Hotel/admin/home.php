﻿<?php  
session_start();  
if(!isset($_SESSION["admin"]))
{
 header("location:index.php");
}
?> 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Administrator	</title>
    <!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
</head>

<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                </button>
                <a class="navbar-brand" href="home.php"> <?php echo $_SESSION["admin"]; ?> </a>
            </div>
        </nav>
        <div class="sidebar-collapse">
            <nav class="navbar-default navbar-side" role="navigation">
                <ul class="nav" id="main-menu">
                    <li>
                        <a  class="active-menu" href="home.php"><i class="fa fa-dashboard"></i> Status</a>
                    </li>
                    <li>
                        <a href="roombook.php"><i class="fa fa-bar-chart-o"></i> Room Booking</a>
                    </li>
                    <li>
                        <a href="payment.php"><i class="fa fa-qrcode"></i> Payment</a>
                    </li>
                    <li>
                        <a  href="room.php"><i class="fa fa-qrcode"></i> Room</a>
                    </li>
                    <li>
                        <a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </nav>
        <!--/. NAV TOP  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Status <small>Room Booking </small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->
				<?php
                    include ('db.php');
                    $sql = "select * from roombook";
                    $re = mysqli_query($con,$sql);
                    $c =0;
                    while($row=mysqli_fetch_array($re) )
                    {
                        $new = $row['stat'];
                        $cin = $row['cin'];
                        $id = $row['id'];
                        if($new=="Not Confirm")
                        {
                            $c = $c + 1;
                        }                
                    }
                ?>
			<div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">
                            <div class="panel-group" id="accordion">
							<div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                        <button class="btn btn-default" type="button">
                                            New Room Bookings  <span class="badge"><?php echo $c ; ?></span>
                                        </button>
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseTwo" class="panel-collapse in" style="height: auto;">
                                    <div class="panel-body">
                                    <div class="panel panel-default">
                            
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Country</th>
                                                <th>Room</th>
                                                <th>Bedding</th>
                                                <th>Meal</th>
                                                <th>Check In</th>
                                                <th>Check Out</th>
                                                <th>Status</th>
                                                <th>More</th>                                            
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                        <?php
                                        $tsql = "select * from roombook";
                                        $tre = mysqli_query($con,$tsql);
                                        while($trow=mysqli_fetch_array($tre) )
                                        {	
                                            $co =$trow['stat']; 
                                            if($co=="Not Confirm")
                                            {
                                                echo"<tr>
                                                    <th>".$trow['id']."</th>
                                                    <th>".$trow['name']."</th>
                                                    <th>".$trow['Email']."</th>
                                                    <th>".$trow['Country']."</th>
                                                    <th>".$trow['TRoom']."</th>
                                                    <th>".$trow['Bed']."</th>
                                                    <th>".$trow['Meal']."</th>
                                                    <th>".$trow['cin']."</th>
                                                    <th>".$trow['cout']."</th>
                                                    <th>".$trow['stat']."</th>
                                                    
                                                    <th><a href='roombook.php?rid=".$trow['id']."' class='btn btn-primary'>Action</a></th>
                                                    </tr>";
                                            }	
                                        
                                        }
                                        ?>
                                            
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- End  Basic Table  --> 
                </div>
            </div>
        </div>
        <?php
        
        $rsql = "SELECT * FROM `roombook`";
        $rre = mysqli_query($con,$rsql);
        $r =0;
        while($row=mysqli_fetch_array($rre) )
        {		
            $br = $row['stat'];
            if($br=="confirm")
            {
                $r = $r + 1;
            }
        }

        ?>
        <div class="panel panel-info">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed">
                    <button class="btn btn-primary" type="button">
                        Booked Rooms  <span class="badge"><?php echo $r ; ?></span>
                    </button>
                    
                    </a>
                </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse" style="height: 0px;">
                    <div class="panel-body">
                    <?php
                    $msql = "SELECT * FROM `roombook`";
                    $mre = mysqli_query($con,$msql);
                    
                    while($mrow=mysqli_fetch_array($mre) )
                    {		
                        $br = $mrow['stat'];
                        if($br=="confirm")
                        {
                            $fid = $mrow['id'];
                                
                        echo"<div class='col-md-3 col-sm-12 col-xs-12'>
                                <div class='panel panel-primary text-center no-boder bg-color-blue'>
                                    <div class='panel-body'>
                                        <i class='fa fa-users fa-5x'></i>
                                        <h3>".$mrow['name']."</h3>
                                    </div>
                                    <div class='panel-footer back-footer-blue'>
                                    <a href=show.php?sid=".$fid ."><button  class='btn btn-primary btn' data-toggle='modal' data-target='#myModal'>
                                Show
                                </button></a>
                                        ".$mrow['TRoom']."
                                    </div>
                                </div>	
                        </div>";
                        }
                    }
                    ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
</div>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/custom-scripts.js"></script>
</body>
</html>
<?php

// include "db.php";
session_start();
if(isset($_SESSION['user'])){
    header("Location: bookingdetails.php");
}

?>
<!doctype html>
<html lang="en" class="no-js">
<head>
	<title>User Login</title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- <link rel="stylesheet" href="css/style.css"> -->
    <style>
        input{
            margin-bottom:10px;
        }
        h1{
            margin:30px 0px;
        }
		nav{
			border-radius:0px !important;
			overflow:hidden;
			width:100vw;
			background: #333;
			position: absolute;
		}
		ul{
			list-style: none;
			float:right;
			margin-right: 20px;			
		}
		li{
			float:left;
			margin: 10px;
			letter-spacing:1px;
		}
		a{
			color: #f5f5f5;	
			outline:none;
			text-decoration:none;
			transition:all .5s;
		}
		a:hover{
			color: #f5f5f5;	
			border-bottom:2px solid #ff0;
		}
	</style>
</head>	
<body>
<nav class="navbar">
    <ul>
        <li>
            <?php 
                echo $_SESSION['user'];
            ?>
        </li>
        <li>
            <a  href="index.php" class="nav-link">Homepage</a>
        </li>
        <li>
            <?php 
                $user = $_SESSION['user'];
                echo "<a class='nav-link' href='bookingdetails.php?user=".$user."'>Booking details</a>"
            ?>
        </li>
        <li>
            <a  href="admin/index.php" class="nav-link">Admin login</a>
        </li>
        <li><a href="login.php" class="nav-link">Login</a></li>
    </ul>
</nav>
	<div class="login-page bk-img">
		<div class="form-content">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<h1 class="text-center text-bold text-light mt-4x">Hotel Management System login</h1>
						<div class="well row bk-light">
							<div class="col-md-8 col-md-offset-2">
								<form method="post">
									<label for="" class="text-uppercase text-sm">Your Username </label>
									<input type="text" placeholder="Username" name="uname" class="form-control mb">
									<label for="" class="text-uppercase text-sm">Password</label>
									<input type="password" placeholder="Password" name="upassword" class="form-control mb">
									<button class="btn btn-primary btn-block" name="login" type="submit">Login</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
<?php
$con = mysqli_connect("localhost","root","","hotel") or die(mysql_error());

if(isset($_POST['login'])){
    $username = $_POST['uname'];
    $userpassword = $_POST['upassword'];

    $sel = "SELECT * FROM roombook WHERE name='$username'";
	$query = mysqli_query($con,$sel);
	
	if($query){
		$count = mysqli_num_rows($query);
		if($count==0){

			echo "not found in roombook";
			$sel1 = "SELECT * FROM payment WHERE name='$username' AND password = '$userpassword'";
			$query1 = mysqli_query($con,$sel1);
			$count1 = mysqli_num_rows($query1);    

			if($count1==1){
				$_SESSION['user'] = $username;
				$_SESSION['checkin'] = "Time to check out";
				$_SESSION['payment'] = " Payment in Pending";
				header("Location: bookingdetails.php?user=".$_SESSION['user']);	
			}else{
				echo "not found in payments";
			}

		}else{
			$_SESSION['user'] = $username;
			$_SESSION['checkin'] = "Still your checkIn";
			header("Location: bookingdetails.php?user=".$_SESSION['user']);
		}
	}else{
		echo mysqli_error($query);
	}

}
?>
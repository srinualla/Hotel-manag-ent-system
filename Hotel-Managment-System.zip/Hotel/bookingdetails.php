<?php
include "db.php";
session_start();
if((!isset($_SESSION['user']))){
header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Booking details</title>
<link href="css/bootstrap.css" rel="stylesheet" />
<style>
nav{
overflow:hidden;
width:100vw;
background: #333;
position: sticky !important;
top:0px;
border-radius:0px !important;
}
ul{
list-style: none;
float:right;
margin-right: 20px;			
}
li{
float:left;
margin: 10px;
letter-spacing:1px;
}
a{
color: #f5f5f5;	
outline:none;
text-decoration:none;
}
a:hover{
color: #f5f5f5;	
border-bottom:2px solid #ff0;
}
.wrap{
background: #E5EBF2;
}
.page-header{
background-color: #d9edf7;
position:absolute;
top:-60px;
width:100%;
}
.panel{
position:absolute;
margin:auto !important;
left:40%;
right:0;
}
</style>
</head>
<body>
<nav class="navbar">
<ul>
<li>
<?php 
echo $_SESSION['user'];
?>
</li>
<li>
<a  href="index.php" class="nav-link">Homepage</a>
</li>
<li>
<?php 
$user = $_SESSION['user'];
echo "<a class='nav-link' href='bookingdetails.php?user=".$user."'>Booking details</a>"
?>
</li>
<li>
<a  href="admin/index.php" class="nav-link">Admin login</a>
</li>
<li><a href="login.php" class="nav-link">Login</a></li>
<li>
<?php
if(isset($_POST['logout'])){
session_destroy();
}
?>
<form action="index.php" method="post">
<button type="submit" name="logout">Logout</button>
</form>
</li>

</ul>
</nav>
<?php
if(!isset($_GET["user"]))
{
header("Location: admin/reservation.php");
}
else {
$curdate=date("Y/m/d");
$name = $_GET['user'];

$sel = "SELECT * FROM roombook WHERE name='$name'";
$query = mysqli_query($con,$sel);

if($query){
$count = mysqli_num_rows($query);
if($count==0){    
$sel1 = "SELECT * FROM payment WHERE name='$name'";
$query1 = mysqli_query($con,$sel1);
$count1 = mysqli_num_rows($query1);

while($row=mysqli_fetch_array($query1))
{
$title = $row['title'];
$name = $row['name'];
$nat = "Indian";
$country = "India";
$troom = $row['troom'];
$nroom = $row['nroom'];
$bed = $row['tbed'];
$non = $row['nroom'];
$meal = $row['meal'];
$cin = $row['cin'];
$cout = $row['cout'];
$sta = "Confirm";
$days = $row['noofdays'];
}
}else{
while($row=mysqli_fetch_array($query))
{
$title = $row['Title'];
$name = $row['name'];
$nat = $row['National'];
$country = $row['Country'];
$troom = $row['TRoom'];
$nroom = $row['NRoom'];
$bed = $row['Bed'];
$non = $row['NRoom'];
$meal = $row['Meal'];
$cin = $row['cin'];
$cout = $row['cout'];
$sta = $row['stat'];
$days = $row['nodays'];
}
}
}


}
?> 

<div id="wrap">
<div id="page-inner">
<div class="row">
<div class="col-md-8 col-sm-8">
<div class="panel panel-info">
<div class="panel-heading">
<?php
if($sta== "Not Confirm")
echo "<h4>Booking Confirmation in process</h4>";
else{
echo "<h4>Booking Confirmed</h4>";
}
?>
</div>
<div class="panel-body">
<?php
if($_SESSION['checkin']=="Time to check out" && $_SESSION['payment']){
echo "<h3>".$_SESSION['checkin']. " || " . $_SESSION['payment'] ."</h3>";
}else if($_SESSION['checkin']=="Time to check out"){
echo "<h3>".$_SESSION['checkin']."</h3>";
}else{
echo "<h3>".$_SESSION['checkin']."</h3>";
}
?>

<div class="table-responsive">
<table class="table">
<tr>
<th>DESCRIPTION</th>
<th>INFORMATION</th>
</tr>
<tr>
<th>Name</th>
<th><?php echo $title.$name; ?> </th>

</tr>
<tr>
<th>Nationality </th>
<th><?php echo $nat; ?></th>

</tr>
<tr>
<th>Country </th>
<th><?php echo $country;  ?></th>

</tr>
<tr>
<th>Type Of the Room </th>
<th><?php echo $troom; ?></th>

</tr>
<tr>
<th>No Of the Room </th>
<th><?php echo $nroom; ?></th>

</tr>
<tr>
<th>Meal Plan </th>
<th><?php echo $meal; ?></th>

</tr>
<tr>
<th>Bedding </th>
<th><?php echo $bed; ?></th>

</tr>
<tr>
<th>Check-in Date </th>
<th><?php echo $cin; ?></th>

</tr>
<tr>
<th>Check-out Date</th>
<th><?php echo $cout; ?></th>

</tr>
<tr>
<th>No of days</th>
<th><?php echo $days; ?></th>

</tr>
<tr>
<th>Status Level</th>
<th><?php echo $sta; ?></th>

</tr>
</table>
</div>
</div>

</body>
</html>